class PVC_gui {
	tag = "PVC_gui";
	class functions {
		file = "functions";
		class playerSpawn {};
		class showGunShopDialog {};
	};
};