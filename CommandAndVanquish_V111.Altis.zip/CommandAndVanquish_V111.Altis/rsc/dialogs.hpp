class pvc_missionSelection {
	idd = 9999;
	movingEnabled = false;
	class controls {
		controls[]=
		{
			pvc_background,
			pvc_frame,
			pvc_textInfantry,
			pvc_DropdownInfantry,
			pvc_DropdownRecon,
			pvc_dropDownSpecial,
			pvc_textRecon,
			pvc_textSpecial,
			pvc_buttonAcceptInfantry,
			pvc_buttonAcceptRecon,
			pvc_buttonAcceptSpecial,
			pvc_title,
			pvc_missionOverview,
			pvc_cancel,
			pvc_missionTitle,
			pvc_description
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT START (by PVT. Collo, v1.063, #Roxyhu)
		////////////////////////////////////////////////////////

		class pvc_background: IGUIBack
		{
			idc = 2200;
			x = 0 * GUI_GRID_W + GUI_GRID_X;
			y = 0 * GUI_GRID_H + GUI_GRID_Y;
			w = 40 * GUI_GRID_W;
			h = 25 * GUI_GRID_H;
		};
		class pvc_frame: RscFrame
		{
			idc = 1800;
			x = 0.5 * GUI_GRID_W + GUI_GRID_X;
			y = 3 * GUI_GRID_H + GUI_GRID_Y;
			w = 38.5 * GUI_GRID_W;
			h = 12.5 * GUI_GRID_H;
		};
		class pvc_textInfantry: RscText
		{
			idc = 1000;
			text = "Infantry Missions"; //--- ToDo: Localize;
			x = 3.5 * GUI_GRID_W + GUI_GRID_X;
			y = 16.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 6.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class pvc_DropdownInfantry: RscCombo
		{
			idc = 2100;
			text = "Select Mission"; //--- ToDo: Localize;
			x = 0.5 * GUI_GRID_W + GUI_GRID_X;
			y = 18.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 12 * GUI_GRID_W;
			h = 1 * GUI_GRID_H;
		};
		class pvc_DropdownRecon: RscCombo
		{
			idc = 2101;
			x = 14 * GUI_GRID_W + GUI_GRID_X;
			y = 18.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 12 * GUI_GRID_W;
			h = 1 * GUI_GRID_H;
		};
		class pvc_dropDownSpecial: RscCombo
		{
			idc = 2102;
			x = 27.5 * GUI_GRID_W + GUI_GRID_X;
			y = 18.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 12 * GUI_GRID_W;
			h = 1 * GUI_GRID_H;
		};
		class pvc_textRecon: RscText
		{
			idc = 1001;
			text = "Recon Missions"; //--- ToDo: Localize;
			x = 16.5 * GUI_GRID_W + GUI_GRID_X;
			y = 16.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 6.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class pvc_textSpecial: RscText
		{
			idc = 1002;
			text = "Special Missions"; //--- ToDo: Localize;
			x = 30 * GUI_GRID_W + GUI_GRID_X;
			y = 16.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 6.5 * GUI_GRID_W;
			h = 2 * GUI_GRID_H;
		};
		class pvc_buttonAcceptInfantry: RscShortcutButton
		{
			idc = 1700;
			text = "Start"; //--- ToDo: Localize;
			x = 0.5 * GUI_GRID_W + GUI_GRID_X;
			y = 20.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 12 * GUI_GRID_W;
			h = 2.5 * GUI_GRID_H;
		};
		class pvc_buttonAcceptRecon: RscShortcutButton
		{
			idc = 1701;
			text = "Start"; //--- ToDo: Localize;
			x = 14 * GUI_GRID_W + GUI_GRID_X;
			y = 20.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 12 * GUI_GRID_W;
			h = 2.5 * GUI_GRID_H;
		};
		class pvc_buttonAcceptSpecial: RscShortcutButton
		{
			idc = 1702;
			text = "Start"; //--- ToDo: Localize;
			x = 27.5 * GUI_GRID_W + GUI_GRID_X;
			y = 20.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 11.5 * GUI_GRID_W;
			h = 2.5 * GUI_GRID_H;
		};
		class pvc_title: RscText
		{
			idc = 1003;
			text = "Missions / Side Quests"; //--- ToDo: Localize;
			x = 0.5 * GUI_GRID_W + GUI_GRID_X;
			y = 0.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 35 * GUI_GRID_W;
			h = 2.5 * GUI_GRID_H;
		};
		class pvc_missionOverview: RscPicture
		{
			idc = 1200;
			text = "#(argb,8,8,3)color(1,1,1,1)";
			x = 20 * GUI_GRID_W + GUI_GRID_X;
			y = 3 * GUI_GRID_H + GUI_GRID_Y;
			w = 19 * GUI_GRID_W;
			h = 12.5 * GUI_GRID_H;
		};
		class pvc_cancel: RscShortcutButton
		{
			idc = 1703;
			text = "X"; //--- ToDo: Localize;
			x = 36.5 * GUI_GRID_W + GUI_GRID_X;
			y = 0.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 3 * GUI_GRID_W;
			h = 1.5 * GUI_GRID_H;
			action = "closeDialog 0";
		};
		class pvc_missionTitle: RscText
		{
			idc = 1004;
			text = "Mission Title"; //--- ToDo: Localize;
			x = 0.5 * GUI_GRID_W + GUI_GRID_X;
			y = 3 * GUI_GRID_H + GUI_GRID_Y;
			w = 19.5 * GUI_GRID_W;
			h = 3 * GUI_GRID_H;
		};
		class pvc_description: RscText
		{
			idc = 1005;
			text = "Description"; //--- ToDo: Localize;
			x = 0.5 * GUI_GRID_W + GUI_GRID_X;
			y = 5.5 * GUI_GRID_H + GUI_GRID_Y;
			w = 18 * GUI_GRID_W;
			h = 10 * GUI_GRID_H;
		};
		////////////////////////////////////////////////////////
		// GUI EDITOR OUTPUT END
		////////////////////////////////////////////////////////
	};
};