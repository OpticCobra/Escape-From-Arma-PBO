
class CfgSounds
{
	sounds[] = {};
	class IARTS_toux1
	{
		name = "IARTS_toux1";
		sound[] = {"IARTS_Command&Vanquish\sounds\toux1.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_toux2
	{
		name = "IARTS_toux2";
		sound[] = {"IARTS_Command&Vanquish\sounds\toux2.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_toux3
	{
		name = "IARTS_toux3";
		sound[] = {"IARTS_Command&Vanquish\sounds\toux3.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_toux4
	{
		name = "IARTS_toux4";
		sound[] = {"IARTS_Command&Vanquish\sounds\toux4.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_toux5
	{
		name = "IARTS_toux5";
		sound[] = {"IARTS_Command&Vanquish\sounds\toux5.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_toux6
	{
		name = "IARTS_toux6";
		sound[] = {"IARTS_Command&Vanquish\sounds\toux6.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_touxGrave
	{
		name = "IARTS_touxGrave";
		sound[] = {"IARTS_Command&Vanquish\sounds\touxGrave.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_mask
	{
		name = "IARTS_mask";
		sound[] = {"IARTS_Command&Vanquish\sounds\mask.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_carBip
	{
		name = "IARTS_carBip";
		sound[] = {"IARTS_Keys\sounds\bip_fermeture_voiture.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_evacuationMessage
	{
		name = "IARTS_evacuationMessage";
		sound[] = {"IARTS_Command&Vanquish\sounds\evacuation_message.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_promoted
	{
		name = "IARTS_promoted";
		sound[] = {"IARTS_Command&Vanquish\sounds\promoted.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_Device
	{
		name = "IARTS_Device";
		sound[] = {"IARTS_Command&Vanquish\sounds\device.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_Intro
	{
		name = "IARTS_Intro";
		sound[] = {"IARTS_Command&Vanquish\sounds\intro.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
	
	class IARTS_Named
	{
		name = "IARTS_Named";
		sound[] = {"IARTS_Command&Vanquish\sounds\named.ogg", 10, 1, 500};
		titles[] = {0,""};
	};
};